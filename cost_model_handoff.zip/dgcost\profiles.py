"""算子形态 profile: 不同 kernel 实现的分段结构与平台常数。

同一套递推能算两种实现, 但它们的 cube 侧行布局不同, 平台常数也不同。
profile 把这些差异收成一个对象, 调用处传进去即可, 不改递推本身。

两个已接入的形态:

  V3_URMA_A5   mc2/all_gather_matmul_v3, arch35, AIV_URMA (WriteNbi/Drain)
               HEAD = tileCnt*tileM 行 1 份 (尾行不在 HEAD)
               MAIN = 每轮 (P-1)*tileM 行
               TAIL = P*paddedTailM 行, 含本卡, 等所有轮
               有 win 槽位回绕 -> 阻塞弧存在
               每轮有 Drain + CrossDevice -> τ_b 可非零

  A2_HCCL      mc2/.../all_gather_matmul, arch22, Hccl<HCCL_SERVER_TYPE_AICPU>
               LOCAL = 全量 m 行 1 份 (独立 localTiling, 见 MatmulKernelLocal)
               MAIN  = 每片 (P-1) 份 (MatmulKernelCompute 里 rank==rankId_ 时 continue)
               TAIL  = 又一片 (P-1) 份 (独立 tailHandleId_, 结构同 MAIN)
               无 BufferChannel/slotNum -> 无阻塞弧, 用 slot_num=轮数
               无 CrossDevice, 靠 hccl_.Wait(handle) -> τ_b = 0
"""

from __future__ import annotations

from dataclasses import dataclass, field

from .params import MmCalib


@dataclass(frozen=True)
class Profile:
    """一个 kernel 实现的分段结构 + 平台常数。"""
    name: str

    # --- cube 侧行布局 ---
    local_covers_full_m: bool
    """本卡块是否覆盖全量 m。

    False (v3): HEAD = tileCnt*tileM, 尾部本卡行归 TAIL。
    True  (A2): LOCAL = m, 尾部本卡行也在 LOCAL 里, TAIL 只有远端。
    """

    tail_includes_local: bool
    """尾块是否含本卡那一份。

    True  (v3): TAIL 是 P 份。
    False (A2): TAIL 是 (P-1) 份, 和 MAIN 同构。
    """

    # --- 平台常数 ---
    max_cube_util: float
    """cube 利用率上限。

    A5 950: 0.95 (MatmulPerformance::MAX_CUBE_UTIL, 也是 L2_PARAMETER_MAP["4_1_1_1_2"] 的首档)
    A2 910B: 0.85 (L2_PARAMETER_MAP 默认行 {128,192,0.85,0.75,0.65} 的首档)
    """

    mm: MmCalib
    """该平台的算力/频率/基本块。"""

    # --- 结构开关, 仅作记录与断言, 实际由 Cut.slot_num 与 CommCalib 控制 ---
    has_slot_reuse: bool = False
    has_per_round_barrier: bool = False


# matmul_performance.h: CYCLE_PER_MICRO_SEC_NPUARCH_3510 = 1.65*1024
# CUBE_CALC_PER_CYCLE_MAP["4_1_1_1_2"] = 8192  (A5, 1 字节 A 矩阵)
V3_URMA_A5 = Profile(
    name="v3-urma-a5",
    local_covers_full_m=False,
    tail_includes_local=True,
    max_cube_util=0.95,
    mm=MmCalib(base_m=256, base_n=256, base_k=128,
               total_computes_per_cycle=8192.0, cycle_per_us=1.65 * 1024, core_num=32),
    has_slot_reuse=True,
    has_per_round_barrier=True,
)

# matmul_performance.h: COMPUTES_PER_CYCLE = 4096, CYCLE_PER_MICRO_SEC = 1.8*1024
# core_num 取 910B 的 AIC 数, 运行时由 GetCoreNumAic() 决定; 这里给一个要调用方覆盖的占位
A2_HCCL = Profile(
    name="a2-hccl",
    local_covers_full_m=True,
    tail_includes_local=False,
    max_cube_util=0.85,
    mm=MmCalib(base_m=256, base_n=256, base_k=128,
               total_computes_per_cycle=4096.0, cycle_per_us=1.8 * 1024, core_num=24),
    has_slot_reuse=False,
    has_per_round_barrier=False,
)

# [2026-10 本机实测标定] A2 / Ascend 910_93 (本机 2 张 910B 芯片), bfloat16, K=4096:
#   20 AIC @1.65GHz; bf16 实测满速 = 每核 4096 MAC/周期 (MAC 忙时间/理论 ≈ 1.01-1.02,
#   故 override=4096, 不做 bf16 减半); 实测 util 在全部测过的形状上饱和到上限
#   (msprof cube_utilization ≈ 99%), 用 mn_threshold=32 表达;
#   base_m 实测小 tile(64 行)仍无 2 倍损失, 取 64。
#   配套通信标定与三项修正见 a2_910_93.py / A2_910_93_CALIBRATION.md。
A2_HCCL_910_93 = Profile(
    name="a2-hccl-910_93",
    local_covers_full_m=True,
    tail_includes_local=False,
    max_cube_util=1.0,
    mm=MmCalib(base_m=64, base_n=64, base_k=128,
               total_computes_per_cycle=4096.0, cycle_per_us=1650.0, core_num=20,
               computes_per_cycle_override=4096.0, mn_threshold=32.0),
    has_slot_reuse=False,
    has_per_round_barrier=False,
)

DEFAULT_PROFILE = V3_URMA_A5
