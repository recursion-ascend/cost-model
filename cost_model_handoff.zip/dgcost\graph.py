"""参考实现: 按 kernel 依赖显式建图再求最长路。

不在 estimate 的调用路径上。它的用处有两个, 都与关键路径输出无关:

  对账基准  estimator 里那条递推是手推的 —— 下标、阻塞弧的守卫、尾块的 max,
            错一个都是静默的错数。改动递推之后跑 check_equivalence, 必须逐位相同。
            第一版的轮结构错就是靠两套独立实现对出来的。
  扩展口    要加一条新的同步、换 cube 出块序、或者做超出"乘一个系数"的非对称卡,
            在图上是加一条弧, 在递推上要重推一遍。

想知道阻塞弧有没有拖累, 看 Estimate.stall_us, 不是看路径。
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

from .estimator import _makespan
from .params import Cut, CommCalib, MmCalib, Shape
from .worktime import block_times, comm_time_round


SRC = "SRC"
SNK = "SNK"


@dataclass
class DisjunctiveGraph:
    """节点权 (工时) + 带权弧。定向后用拓扑序一次前推求最长路。"""
    dur: Dict[str, float] = field(default_factory=dict)
    arcs: List[Tuple[str, str, float]] = field(default_factory=list)   # (u, v, 弧权=延迟)
    kind: Dict[str, str] = field(default_factory=dict)                 # 节点类别, 供画图/分析

    def add_node(self, name: str, duration: float, kind: str) -> None:
        self.dur[name] = duration
        self.kind[name] = kind

    def add_arc(self, u: str, v: str, w: float = 0.0) -> None:
        self.arcs.append((u, v, w))

    def longest_path(self) -> Tuple[float, List[str]]:
        """返回 (makespan, 关键路径节点序列)。图必须是 DAG。"""
        succ: Dict[str, List[Tuple[str, float]]] = {u: [] for u in self.dur}
        indeg: Dict[str, int] = {u: 0 for u in self.dur}
        for u, v, w in self.arcs:
            succ[u].append((v, w))
            indeg[v] += 1
        order: List[str] = [u for u in self.dur if indeg[u] == 0]
        topo: List[str] = []
        queue = list(order)
        while queue:
            u = queue.pop()
            topo.append(u)
            for v, _ in succ[u]:
                indeg[v] -= 1
                if indeg[v] == 0:
                    queue.append(v)
        if len(topo) != len(self.dur):
            raise ValueError("析取图成环: 弧定向或槽位深度不自洽")
        start: Dict[str, float] = {u: 0.0 for u in self.dur}
        pred: Dict[str, str] = {}
        for u in topo:
            fin = start[u] + self.dur[u]
            for v, w in succ[u]:
                if fin + w > start[v]:
                    start[v] = fin + w
                    pred[v] = u
        end_node = max(self.dur, key=lambda u: start[u] + self.dur[u])
        makespan = start[end_node] + self.dur[end_node]
        path: List[str] = [end_node]
        while path[-1] in pred:
            path.append(pred[path[-1]])
        return makespan, list(reversed(path))


def build_graph(shape: Shape, comm: CommCalib, mm: MmCalib, cut: Cut,
                head_first: bool = True,
                rank_skew: Optional[List[float]] = None,
                couple_ranks: bool = True) -> DisjunctiveGraph:
    """按 kernel 的实际依赖建图。

    head_first: cube 上 HEAD 本地块是否排在 MAIN 块之前, 对应 fit_balance 的
                LocalMMPosition::FRONT。注意这一条**无法从本仓证实**:
                出块序由 BlockSchedulerQuantBatchMatmulV3 决定, 而
                blaze/gemm/block/block_scheduler_qbmm.h 是 SDK 件, 不在本仓;
                且每个 AIC 核各自走 while (sch.GetTileIdx(...)) 并各自持 readyTileIdx,
                HEAD 是否构成串行前缀取决于该调度器。翻成 False 即 "本地块后置"。
    rank_skew:  每卡通信工时的乘性偏置, 用来看 straggler 效应 (默认全 1.0)。
    couple_ranks: True = 每轮一个跨卡 rendezvous 节点, 对应 DoWait 里的
                  Drain + TeamBarrier.CrossDevice; False = 各卡独立, 用于对比单卡标量模型。
    """
    m = shape.m_per_rank
    P = shape.rank_size
    rows = cut.comm_rounds(m)
    R = len(rows)
    tc = cut.tile_cnt(m)            # MAIN 轮数; 尾轮 (若有) 的下标是 tc
    has_tail = cut.tail_m(m) > 0
    S = max(1, min(cut.slot_num, R))
    skew = rank_skew or [1.0] * P
    block_arc_w = comm.release_us + comm.blocked_barrier_us

    th, tm, tt = block_times(shape, mm, cut)

    g = DisjunctiveGraph()
    g.add_node(SRC, 0.0, "src")
    g.add_node(SNK, 0.0, "snk")

    for p in range(P):
        # --- 节点 ---
        if th > 0.0:
            g.add_node(f"H[{p}]", th, "mm_head")
        for r, rows_r in enumerate(rows):
            g.add_node(f"X[{p},{r}]", comm_time_round(shape, comm, rows_r) * skew[p], "comm")
        for r in range(tc):
            g.add_node(f"M[{p},{r}]", tm[r], "mm_main")
        if has_tail:
            g.add_node(f"T[{p}]", tt, "mm_tail")

        # --- C: 合取弧 ---
        # 算子级一次性启动开销 c 压在首轮通信前, 通信工时最前段无处可藏
        g.add_arc(SRC, f"X[{p},0]", comm.fixed_overhead_us)
        if th > 0.0:
            g.add_arc(SRC, f"H[{p}]", 0.0)
            g.add_arc(f"H[{p}]", SNK, 0.0)

        for r in range(R):
            bar = f"BAR[{r}]" if couple_ranks else f"BAR[{p},{r}]"
            if bar not in g.dur:
                g.add_node(bar, comm.barrier_us, "barrier")
            # drain + rendezvous: 本轮通信完成 -> 本轮 barrier
            g.add_arc(f"X[{p},{r}]", bar, 0.0)
            # 同一 AIV 的下一轮 Commit 在本轮 Wait 之后 (egress 串行 + 本轮 barrier 之后)
            if r + 1 < R:
                g.add_arc(bar, f"X[{p},{r+1}]", 0.0)
                g.add_arc(f"X[{p},{r}]", f"X[{p},{r+1}]", 0.0)
            # --- 阻塞弧 (本模型的核心): 槽位 r-S 被 r 复用, 需 AIC 先消费完并 Release ---
            # 消费 round j 的是 M[j] (j < tc); 尾轮的槽位落在最后 S 轮里, kernel 不 Release 它
            if r >= S and (r - S) < tc:
                g.add_arc(f"M[{p},{r-S}]", f"X[{p},{r}]", block_arc_w)

        for r in range(tc):
            # data-ready flag: dependTileIdx = roundIdx+1 -> MAIN[r] 等 round r
            g.add_arc(f"BAR[{r}]" if couple_ranks else f"BAR[{p},{r}]", f"M[{p},{r}]", 0.0)
            # cube 机器序: MAIN 块按 round 升序
            if r + 1 < tc:
                g.add_arc(f"M[{p},{r}]", f"M[{p},{r+1}]", 0.0)
            g.add_arc(f"M[{p},{r}]", SNK, 0.0)

        if has_tail:
            # TAIL 的 dependTileIdx = commTurn: 等**所有**轮。各轮通信串行, 故等末轮即等全部
            g.add_arc(f"BAR[{R-1}]" if couple_ranks else f"BAR[{p},{R-1}]", f"T[{p}]", 0.0)
            if tc > 0:
                g.add_arc(f"M[{p},{tc-1}]", f"T[{p}]", 0.0)
            g.add_arc(f"T[{p}]", SNK, 0.0)

        # --- D 中已定向的那条: HEAD 与 MAIN/TAIL 在同一 cube 阵列上的先后 ---
        if th > 0.0:
            last_cube = f"T[{p}]" if has_tail else (f"M[{p},{tc-1}]" if tc > 0 else None)
            if head_first:
                if tc > 0:
                    g.add_arc(f"H[{p}]", f"M[{p},0]", 0.0)
                elif has_tail:
                    g.add_arc(f"H[{p}]", f"T[{p}]", 0.0)
            elif last_cube is not None:
                g.add_arc(last_cube, f"H[{p}]", 0.0)

    return g


def check_equivalence(shape: Shape, comm: CommCalib, mm: MmCalib, cut: Cut,
                      slow_rank_factor: float = 1.0, head_first: bool = True) -> float:
    """递推与显式建图的差值。正常恒为 0, 改过递推之后跑一遍。

    慢卡在图里是给某一张卡加偏置, 在递推里是给 τ_x 乘系数。每轮的 rendezvous 全卡共享,
    最慢卡决定当轮, 所以两者等价 —— 这正是需要对账的那类等价。
    """
    skew = [1.0] * shape.rank_size
    if slow_rank_factor != 1.0 and shape.rank_size > 1:
        skew[1] = slow_rank_factor
    graph_us = build_graph(shape, comm, mm, cut, head_first=head_first,
                           rank_skew=skew).longest_path()[0]
    recur_us = _makespan(shape, comm, mm, cut, slow_rank_factor, head_first)
    return abs(graph_us - recur_us)
