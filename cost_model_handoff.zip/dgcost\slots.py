"""win 区足迹、可用量预算, 以及槽深下界。"""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import List, Optional

from .estimator import estimate
from .params import Cut, CommCalib, MmCalib, Shape
from .worktime import block_times, comm_time_round


@dataclass
class WinLayout:
    """win 区足迹, 口径同 AllGatherMxMatmulUrmaImpl::Init 的两次 Init。

    每槽是 (P-1) 段 remote tile 而不是 P 段: 本卡数据从自己的 GM 读, 从不进 win。
    data 段按 slotNum 回绕, scale 段恒为 totalTiles 个槽全量。
    行数口径是 totalTiles * maxTileSize 而不是 m: 尾块也按 maxTileSize 占满一个槽。
    """
    total_tiles: int
    max_tile: int
    data_slot_bytes: int
    scale_slot_bytes: int

    @property
    def full_bytes(self) -> int:
        return self.total_tiles * (self.data_slot_bytes + self.scale_slot_bytes)

    def bytes_at(self, slot_num: int) -> int:
        return slot_num * self.data_slot_bytes + self.total_tiles * self.scale_slot_bytes


def win_layout(shape: Shape, tile_m: int) -> WinLayout:
    rows = Cut(tile_m, 1).comm_rounds(shape.m_per_rank)
    max_tile = max(rows)
    fanout = shape.rank_size - 1
    return WinLayout(total_tiles=len(rows), max_tile=max_tile,
                     data_slot_bytes=fanout * max_tile * shape.data_row_bytes,
                     scale_slot_bytes=fanout * max_tile * shape.scale_row_bytes)


@dataclass
class WinBudget:
    """win 区可用量 —— 参数, 不是常数。

    host 的 WIN_REUSE_BUDGET_CAP 写死 400MB, apace_common_utils.h 的注释给的出处是
    "HCCL_BUFFSIZE 默认 200MB, 框架层翻倍分配为 400MB"。这个翻倍关系本仓证实不了:
    torch 层 _check_hccl_buffer 按 1 倍校验, 两层口径已经矛盾。模型因此不替 host 选边,
    默认 400MB 与 host 当前行为一致, 要看别的可用量直接换 total_bytes。

    reserved_bytes 默认 0 是为了与 host 的 slotNum 决策逐位一致 —— 那段没有扣预留,
    2MB 预留只出现在 CheckHcclBufferSizeAttr 的另一套口径里。
    """
    total_bytes: int = 400 * 1024 * 1024
    reserved_bytes: int = 0
    depth_cap: int = 128      # WIN_REUSE_DEPTH_CAP
    depth_min: int = 2        # WIN_REUSE_DEPTH_MIN

    @property
    def usable_bytes(self) -> int:
        return max(0, self.total_bytes - self.reserved_bytes)


def tiling_slot_num(shape: Shape, tile_m: int, budget: Optional[WinBudget] = None) -> int:
    """复刻 all_gather_matmul_v3_tiling.cpp 的 slotNum 决策, 预算改为入参。

    全量装得下就不复用; 否则先扣掉 scale 段的全量占用, 在剩余预算里取最深的 data 槽数,
    与深度上限和 totalTiles 取小, 最后抬到下限。
    """
    bud = budget or WinBudget()
    wl = win_layout(shape, tile_m)
    cap = bud.usable_bytes
    if wl.full_bytes <= cap:
        return max(wl.total_tiles, bud.depth_min)
    scale_fixed = wl.total_tiles * wl.scale_slot_bytes
    left = max(0, cap - scale_fixed)
    depth = wl.total_tiles if wl.data_slot_bytes == 0 else left // wl.data_slot_bytes
    return max(min(bud.depth_cap, depth, wl.total_tiles), bud.depth_min)


def min_slot_depth(shape: Shape, comm: CommCalib, mm: MmCalib, cut: Cut,
                   slow_rank_factor: float = 1.0) -> int:
    """让槽位回绕不掐住通信链所需的最小槽深。

    阻塞在 r = 0 处最紧: X[S] 无阻塞时最早在 c + S*τ_x 起步, 而 M[0] 在
    max(c + τ_x, τ_h) + τ_m 完成, 其后还要 release 与阻塞分支的额外汇合。于是

        S_min = min( R, max( 2, ceil( (max(c+τ_x, τ_h) + τ_m + release + blockedBar − c) / τ_x ) ) )

    对 R 截断是因为 S ≥ R 时槽位不回绕, 阻塞根本不存在。下限 2 来自 S = 1 等于把两条链
    完全串行, 与 host 的 WIN_REUSE_DEPTH_MIN 同值。

    适用域是通信链为关键链, 见 comm_chain_is_critical; 域外 cube 链主导, 本式偏保守。
    """
    m = shape.m_per_rank
    rows = cut.comm_rounds(m)
    R = len(rows)
    if cut.tile_cnt(m) == 0:
        return min(R, 2)
    tx = comm_time_round(shape, comm, rows[0]) * slow_rank_factor + comm.barrier_us
    if tx <= 0.0:
        return min(R, 2)
    head, main, _ = block_times(shape, mm, cut)
    c = comm.fixed_overhead_us
    need = (max(c + tx, head) + main[0] + comm.release_us + comm.blocked_barrier_us - c) / tx
    return min(R, max(2, math.ceil(need)))


def comm_chain_is_critical(shape: Shape, comm: CommCalib, mm: MmCalib, cut: Cut,
                           slow_rank_factor: float = 1.0) -> bool:
    """min_slot_depth 的适用域判定: 无阻塞时通信链是否长于 cube 链。"""
    if cut.tile_cnt(shape.m_per_rank) == 0:
        return False
    est = estimate(shape, comm, mm, Cut(cut.tile_m, len(cut.comm_rounds(shape.m_per_rank))),
                   slow_rank_factor=slow_rank_factor)
    _, main, _ = block_times(shape, mm, cut)
    return est.comm_chain_us + main[-1] > est.cube_chain_us


def slot_depth_vs_budget(shape: Shape, comm: CommCalib, mm: MmCalib, tile_m: int,
                         budgets_mb: Optional[List[int]] = None) -> List[dict]:
    """预算 -> 槽深 -> 阻塞代价。

    S_min 是"不被掐住所需的槽深", 预算给出的 slotNum 是"实际拿得到的槽深",
    两者相比才有意义。
    """
    if budgets_mb is None:
        budgets_mb = [64, 128, 200, 256, 400, 512, 1024]
    R = len(Cut(tile_m, 1).comm_rounds(shape.m_per_rank))
    wl = win_layout(shape, tile_m)
    s_min = min_slot_depth(shape, comm, mm, Cut(tile_m, R))
    out = []
    for mb in budgets_mb:
        slot = tiling_slot_num(shape, tile_m, WinBudget(total_bytes=mb * 1024 * 1024))
        est = estimate(shape, comm, mm, Cut(tile_m, slot))
        out.append({"budget_mb": mb, "slot_num": slot, "rounds": R, "s_min": s_min,
                    "used_bytes": wl.bytes_at(est.slot_num), "full_bytes": wl.full_bytes,
                    "makespan_us": est.makespan_us, "stall_us": est.stall_us,
                    "starved": slot < s_min})
    return out
