"""

  通信  comm_model.h   CommTime
  计算  matmul_model.h FindCubeUtil / CalcMatmulGradient
        solver.h       MatmulTime
        fit_balance_tiling.h FinalizeMmModelParams (localMMTime)

"""

from __future__ import annotations

from typing import List, Tuple

from .params import BYTES_PER_MB, Cut, CommCalib, MmCalib, Shape
from .profiles import DEFAULT_PROFILE, Profile


MAX_UTIL = 0.95
AVG_UTIL = 0.75
MN_THRESHOLD = 820.0
K_THRESHOLD = 1280.0
MAX_ENHANCE = 1.4
EXP_PIPE = 0.7     # CUBE_UTIL_EXPONENT_COEFFICIENT
EXP_LOCAL = 0.6    # LOCAL_MM_UTIL_EXPONENT_COEFFICIENT


def cube_util(shape: Shape, m_size: int, shares: int, mn_exponent: float,
              max_util: float = MAX_UTIL, mn_threshold: float = MN_THRESHOLD) -> float:
    """matmul_model.h FindCubeUtil。

    max_util 是平台的利用率上限: A5 950 为 0.95, A2 910B 为 0.85
    (L2_PARAMETER_MAP 默认行 {128,192,0.85,0.75,0.65} 的首档)。
    mn_threshold 默认 = 仓内 820; 平台实测 util 饱和点不同时由 MmCalib.mn_threshold 传入
    (A2/910_93 本机标定为 32, 见 A2_910_93_CALIBRATION.md)。
    """
    if m_size <= 0 or shares <= 0 or shape.n <= 0:
        return 0.0
    harmonic = (m_size * shares * shape.n) / float(m_size * shares + shape.n)
    k_term = min(MAX_ENHANCE, (shape.k / K_THRESHOLD) ** EXP_PIPE)
    mn_term = min(MAX_ENHANCE, (harmonic / mn_threshold) ** mn_exponent)
    return min(max_util, AVG_UTIL * k_term * mn_term)


def mm_shares(shape: Shape) -> int:
    """FitBalanceCut 的 shares: FRONT 形态下有一份数据不经通信 -> rankDim-1。"""
    return max(1, shape.rank_size - 1)


def mm_gradient(shape: Shape, mm: MmCalib, max_util: float = MAX_UTIL) -> float:
    """CalcMatmulGradient: 每行耗时系数 (us/row)。

    util 的自变量是**全量 mValue**, 不是块长, 所以 gradient 是整个算子一个常数,
    块耗时对块长严格线性。按块重算 util 会让小块显得利用率更低, 与仓内不符。
    """
    util = cube_util(shape, shape.m_per_rank, mm_shares(shape), EXP_PIPE, max_util,
                     mn_threshold=mm.mn_threshold)
    if util <= 0.0:
        return float("inf")
    tmp_n = max(mm.base_n, shape.n)
    tmp_k = max(mm.base_k, shape.k)
    return (tmp_n * tmp_k) / (mm.computes_per_cycle(shape.a_bits) * mm.cycle_per_us
                              * mm.core_num * util)


def mm_time_block(shape: Shape, mm: MmCalib, tile_rows: int, row_mul: int,
                  max_util: float = MAX_UTIL) -> float:
    """solver.h MatmulTime: max(baseM, tileSize) * rowMul * gradient。

    baseM 下限作用在单个 m 方向块上, 再乘份数。
    """
    if tile_rows <= 0 or row_mul <= 0:
        return 0.0
    return max(mm.base_m, tile_rows) * row_mul * mm_gradient(shape, mm, max_util)


def local_mm_time(shape: Shape, mm: MmCalib, head_rows: int,
                  max_util: float = MAX_UTIL) -> float:
    """FinalizeMmModelParams 的 localMMTime: MatmulTime(rows, 1) / localMMUtil。

    仓内在这里对利用率除了两次 —— gradient 内已含 util_{0.7, shares}, 外面再除
    util_{0.6, 1}。照抄这个口径, 本文件要与 host 用同一把尺。
    """
    if head_rows <= 0:
        return 0.0
    u_local = cube_util(shape, shape.m_per_rank, 1, EXP_LOCAL, max_util,
                        mn_threshold=mm.mn_threshold)
    t = mm_time_block(shape, mm, head_rows, 1, max_util)
    return t / u_local if abs(u_local) > 1e-10 else t


def comm_time_round(shape: Shape, comm: CommCalib, rows: int) -> float:
    """一轮通信的持续时间 y = k*x + b, 不含算子级一次性 c。"""
    return comm.slope_us_per_mb * rows * shape.comm_row_bytes / BYTES_PER_MB + comm.round_overhead_us


def block_times(shape: Shape, mm: MmCalib, cut: Cut,
                profile: Profile = DEFAULT_PROFILE) -> Tuple[float, List[float], float]:
    """按 profile 的 logical M 布局给出 (τ_h, [τ_m], τ_t)。

    v3 (local_covers_full_m=False, tail_includes_local=True),
    all_gather_qbmm_mx_kernel.h Run():
      headMainRows  = tileCnt * tileM        本卡数据, 1 份, 尾行不在其中
      mainRoundRows = (P-1) * tileM          每轮, 远端数据
      tailRows      = P * paddedTailM        含本卡, P 份

    A2 (local_covers_full_m=True, tail_includes_local=False),
    all_gather_matmul_full_mesh.h + all_gather_matmul_base.h:
      LOCAL = m                              独立 localTiling, MatmulKernelLocal()
      MAIN  = (P-1) 份                       MatmulKernelCompute 跳过 rank==rankId_
      TAIL  = (P-1) 份                       独立 tailHandleId_, 结构同 MAIN
    """
    m, P = shape.m_per_rank, shape.rank_size
    mu = profile.max_cube_util
    local_rows = m if profile.local_covers_full_m else cut.head_rows(m)
    head = local_mm_time(shape, mm, local_rows, mu)
    main = [mm_time_block(shape, mm, cut.tile_m, P - 1, mu)] * cut.tile_cnt(m)
    tail_shares = P if profile.tail_includes_local else max(1, P - 1)
    tail = mm_time_block(shape, mm, cut.padded_tail_m(m), tail_shares, mu)
    return head, main, tail
