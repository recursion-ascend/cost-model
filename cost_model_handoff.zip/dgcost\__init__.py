# -*- coding: utf-8 -*-
"""
AllGatherMatmulV3 @ Ascend 950 (arch35 / URMA-UDMA path) 的时长估算模型。

给定形状、标定与切分, 返回一次 kernel 执行的预估耗时与分解:

    from dgcost import Shape, CommCalib, MmCalib, Cut, estimate
    est = estimate(Shape(m_per_rank=4096, k=4096, n=1024, rank_size=4),
                   CommCalib(26.5894, 33.17, 20.58), MmCalib(core_num=32),
                   Cut(tile_m=512, slot_num=8))
    est.makespan_us, est.bound, est.stall_us

模型是一条前推递推: 通信链与计算链逐轮交替推进, 两条链之间有三类耦合, 都来自 kernel
写死的依赖 —— 每轮的跨卡 rendezvous、data-ready flag、以及 win 槽位回绕带来的反向阻塞。
递推式与各项的出处见同目录 disjunctive_graph_cost_model.md。

模块划分:
    params      形状 / 标定 / 切分决策
    worktime    工时函数, 逐条对齐仓内 fit_balance_tiling
    estimator   递推式与 Estimate
    slots       win 足迹、预算、槽深下界
    search      (tileM, slotNum) 搜索
    graph       显式建图的参考实现, 递推的对账基准
    profiles    算子形态 (v3-urma-a5 / a2-hccl) 的分段结构与平台常数
    calib       从仓内 C++ 实测拟合表构造标定
    demo        示例场景

!! 标定状态: 仓内没有任何算子填过 AIV_URMA 标定行。{AIV_URMA, 4, 3.2, 4.45, 1.8} 只出现在
   fit_balance_tiling/README.md 的示例代码块里, 注释自述为演示数; 唯一实测行
   {AICPU, 4, 26.5894, 33.17, 20.58} 标的是 AICPU/HCCL 路径, 与本算子的 WriteNbi/Drain
   不是同一条链路。故本包算出的绝对微秒数都是借位的, 只能看结构性结论, 不能用来定块长。
"""

from .params import (BYTES_PER_MB, MAX_COMM_ROUNDS, M_TAIL_ALIGN,
                     CommCalib, Cut, MmCalib, Shape)
from .worktime import (block_times, comm_time_round, cube_util, local_mm_time,
                       mm_gradient, mm_shares, mm_time_block)
from .estimator import Estimate, estimate, fit_balance_estimate
from .slots import (WinBudget, WinLayout, comm_chain_is_critical, min_slot_depth,
                    slot_depth_vs_budget, tiling_slot_num, win_layout)
from .search import TILE_CANDIDATES, sweep
from .graph import DisjunctiveGraph, build_graph, check_equivalence
from .profiles import A2_HCCL, A2_HCCL_910_93, DEFAULT_PROFILE, V3_URMA_A5, Profile
from .calib import (A2_FULLMESH, A3_DOUBLERING, A5_ALLGATHER_4P, A5_FULLMESH_GENERIC,
                    HcclFit, a5_allgather_4p, comm_calib_from_fit, full_mesh_comm_time_factor)
from . import a2_910_93

__all__ = [
    "BYTES_PER_MB", "MAX_COMM_ROUNDS", "M_TAIL_ALIGN",
    "Shape", "CommCalib", "MmCalib", "Cut",
    "cube_util", "mm_shares", "mm_gradient", "mm_time_block", "local_mm_time",
    "comm_time_round", "block_times",
    "Estimate", "estimate", "fit_balance_estimate",
    "WinLayout", "win_layout", "WinBudget", "tiling_slot_num",
    "min_slot_depth", "comm_chain_is_critical", "slot_depth_vs_budget",
    "TILE_CANDIDATES", "sweep",
    "DisjunctiveGraph", "build_graph", "check_equivalence",
    "Profile", "V3_URMA_A5", "A2_HCCL", "A2_HCCL_910_93", "DEFAULT_PROFILE",
    "HcclFit", "A5_ALLGATHER_4P", "A5_FULLMESH_GENERIC", "A2_FULLMESH", "A3_DOUBLERING",
    "comm_calib_from_fit", "a5_allgather_4p", "full_mesh_comm_time_factor",
    "a2_910_93",
]
