"""时长估计: 递推式与它的结果结构。

递推由第 6 节的析取图推出, 两者逐位等价 —— 见 graph.check_equivalence。
"""

from __future__ import annotations

from dataclasses import dataclass

from .params import BYTES_PER_MB, Cut, CommCalib, MmCalib, Shape
from .profiles import DEFAULT_PROFILE, Profile
from .worktime import block_times, comm_time_round, mm_time_block


@dataclass
class Estimate:
    """一次执行的预估耗时与分解。所有字段单位 us。"""
    makespan_us: float
    comm_chain_us: float     # c + Σ(τ_x + τ_b), 通信累计工时
    cube_chain_us: float     # τ_h + Σ τ_m + τ_t, 矩阵乘累计工时
    head_us: float
    tail_us: float
    stall_us: float          # 槽深不足的额外等待 = makespan − 槽位无限时的 makespan
    rounds: int
    slot_num: int            # 实际生效的槽深 min(slotNum, rounds)

    @property
    def serial_us(self) -> float:
        """完全不重叠的上界。"""
        return self.comm_chain_us + self.cube_chain_us

    @property
    def overlap_us(self) -> float:
        """被流水掩盖掉的部分。"""
        return self.serial_us - self.makespan_us

    @property
    def bound(self) -> str:
        return "comm" if self.comm_chain_us >= self.cube_chain_us else "cube"

    def __str__(self) -> str:
        return (f"{self.makespan_us:.2f} us  [{self.bound} bound] "
                f"comm {self.comm_chain_us:.1f} / cube {self.cube_chain_us:.1f} / "
                f"掩盖 {self.overlap_us:.1f} / 阻塞 {self.stall_us:.1f} "
                f"| {self.rounds} 轮 槽深 {self.slot_num}")


def _makespan(shape: Shape, comm: CommCalib, mm: MmCalib, cut: Cut,
              slow_rank_factor: float, head_first: bool,
              profile: Profile = DEFAULT_PROFILE) -> float:
    """前推递推。通信与计算两侧逐轮交替推进。

      fx(r) = max( fx(r−1), fm(r−S) + release + blockedBar ) + τ_x(r) + τ_b
              第二项仅当 r ≥ S 且 r − S < tileCnt       fx(−1) = c
      fm(r) = max( fx(r), fm(r−1) ) + τ_m(r)             r < tileCnt, fm(−1) = τ_h
      ft    = max( fx(R−1), fm(tileCnt−1) ) + τ_t        有尾块时

    每轮的 rendezvous 是全卡共享的, 所以最慢卡的通信工时就是当轮的有效工时 ——
    slow_rank_factor 直接乘在 τ_x 上即可代入 straggler, 不需要逐卡展开。
    head_first=False 把本地块挪到末尾, 对应 LocalMMPosition::BACK。
    """
    m = shape.m_per_rank
    rows = cut.comm_rounds(m)
    R = len(rows)
    tile_cnt = cut.tile_cnt(m)
    has_tail = cut.tail_m(m) > 0
    slots = max(1, min(cut.slot_num, R))
    block_delay = comm.release_us + comm.blocked_barrier_us

    head, main, tail = block_times(shape, mm, cut, profile)
    comm_round = [comm_time_round(shape, comm, r) * slow_rank_factor for r in rows]

    fx = [0.0] * R          # 第 r 轮通信含汇合的完成时刻
    fm = [0.0] * tile_cnt   # 第 r 轮 MAIN 块的完成时刻
    for r in range(R):
        start = comm.fixed_overhead_us if r == 0 else fx[r - 1]
        if r >= slots and (r - slots) < tile_cnt:          # 槽位回绕: 等 AIC Release
            start = max(start, fm[r - slots] + block_delay)
        fx[r] = start + comm_round[r] + comm.barrier_us
        if r < tile_cnt:
            ready = fx[r] if r == 0 else max(fx[r], fm[r - 1])
            if r == 0 and head_first:
                ready = max(ready, head)                   # HEAD 先占 cube
            fm[r] = ready + main[r]

    if has_tail:
        cube_done = fm[tile_cnt - 1] if tile_cnt else (head if head_first else 0.0)
        end = max(fx[R - 1], cube_done) + tail
    else:
        end = fm[tile_cnt - 1] if tile_cnt else fx[R - 1]
    return end + (0.0 if head_first else head)


def estimate(shape: Shape, comm: CommCalib, mm: MmCalib, cut: Cut,
             slow_rank_factor: float = 1.0, head_first: bool = True,
             profile: Profile = DEFAULT_PROFILE) -> Estimate:
    """预估一次执行的耗时, 连同分解一起返回。"""
    rows = cut.comm_rounds(shape.m_per_rank)
    R = len(rows)
    head, main, tail = block_times(shape, mm, cut, profile)

    comm_chain = comm.fixed_overhead_us + sum(
        comm_time_round(shape, comm, r) * slow_rank_factor + comm.barrier_us for r in rows)
    cube_chain = head + sum(main) + tail

    mk = _makespan(shape, comm, mm, cut, slow_rank_factor, head_first, profile)
    # 槽位无限时的同一形态, 两者之差就是槽深带来的额外等待
    free = _makespan(shape, comm, mm, Cut(cut.tile_m, R), slow_rank_factor, head_first, profile)

    return Estimate(makespan_us=mk, comm_chain_us=comm_chain, cube_chain_us=cube_chain,
                    head_us=head, tail_us=tail, stall_us=mk - free,
                    rounds=R, slot_num=max(1, min(cut.slot_num, R)))


def fit_balance_estimate(shape: Shape, comm: CommCalib, mm: MmCalib, cut: Cut) -> float:
    """仓内 EstimateCutTotalTime 的 FRONT 分支, 用于并排对照。

    它没有阻塞弧也没有跨卡耦合, 相当于本模型取 S ≥ R 且 τ_b = 0 的特例。
    """
    m, P = shape.m_per_rank, shape.rank_size
    rows = cut.comm_rounds(m)
    R = len(rows)
    total_mm = mm_time_block(shape, mm, m, P)
    total_comm = (comm.slope_us_per_mb * m * shape.comm_row_bytes / BYTES_PER_MB
                  + comm.round_overhead_us * R + comm.fixed_overhead_us)
    if R <= 1:
        return total_comm + total_mm
    comm_first = comm.fixed_overhead_us + comm_time_round(shape, comm, rows[0])
    mm_last = mm_time_block(shape, mm, rows[-1], P)
    return comm_first + max(total_comm - comm_first, total_mm - mm_last) + mm_last
