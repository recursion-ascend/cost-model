"""形状、标定与切分决策 —— 模型的全部入参。"""

from __future__ import annotations

from dataclasses import dataclass
from typing import List

BYTES_PER_MB = 1024.0 * 1024.0
M_TAIL_ALIGN = 16        # host 的 M_TAIL_ALIGN / kernel 的 kPaddingLength
MAX_COMM_ROUNDS = 63     # 通信 API 的 FFTS 队列上限


@dataclass
class Shape:
    
    m_per_rank: int
    k: int
    n: int
    rank_size: int
    a_bits: int = 8          # MXFP8_BITS=8 / MXFP4_BITS=4

    @property
    def data_row_bytes(self) -> int:
        return self.k * self.a_bits // 8

    @property
    def scale_row_bytes(self) -> int:
        """scaleKGroups = ceil(k/64), 每组 MXFP_MULTI_BASE_SIZE=2 字节。"""
        return ((self.k + 63) // 64) * 2

    @property
    def comm_row_bytes(self) -> int:
        """进入通信拟合式的每行字节数 = 仅 data 段。

        kernel 一轮里 scale 与 data 都 Commit 一次, 同走一条 channel。但仓内 CommTime 的
        自变量是 mSize * commMatrixLen * realDtypeSize, 只有 data; scale 流量与 (P-1) 扇出
        都被拟合斜率吸收。在同一条斜率上再加 scale 字节等于重复计一次。
        scale 字节仍参与 win 足迹, 见 win_layout —— 两处口径不同, 不要混。
        """
        return self.data_row_bytes


@dataclass
class CommCalib:
    """通信标定 y = k*x + b, 另加算子级一次性 c。

    k/b 按 (引擎, 卡数) 标定, (P-1) 扇出与 scale 流量都已被 k 吸收。
    后三项仓内没有单独建模, 都被 b 吸收; 它们随 P 增长而 b 不随, 能单独实测时再填。
    """
    slope_us_per_mb: float
    round_overhead_us: float
    fixed_overhead_us: float = 0.0
    barrier_us: float = 0.0           # DoWait 里的 TeamBarrier.CrossDevice
    release_us: float = 0.0           # AIC Release -> AIV 看到 flag
    blocked_barrier_us: float = 0.0   # 阻塞分支多出的 SyncAll + 第二次 CrossDevice


@dataclass
class MmCalib:
    """计算标定: matmul_model.h 的公式 + 950 平台规格。"""
    base_m: int = 256
    base_n: int = 256
    base_k: int = 128
    total_computes_per_cycle: float = 8192.0
    cycle_per_us: float = 1.65 * 1024.0
    core_num: int = 32
    computes_per_cycle_override: float = 0.0
    mn_threshold: float = 820.0
    """FindCubeUtil 的 MN 饱和阈值 (仓内为 820)。实测 util 饱和点不同的平台按需覆盖;
    A2/910_93 本机标定为 32 (见 dgcost/A2_910_93_CALIBRATION.md)。"""

    def computes_per_cycle(self, a_bits: int) -> float:
        if self.computes_per_cycle_override > 0.0:
            return self.computes_per_cycle_override
        return self.total_computes_per_cycle / (a_bits / 8.0)


@dataclass
class Cut:
    """切分决策。tile_m 对应 host 的 COMM_TILE_M, slot_num 对应 commTile.slotNum。"""
    tile_m: int
    slot_num: int

    def tile_cnt(self, m: int) -> int:
        return m // self.tile_m

    def tail_m(self, m: int) -> int:
        return m % self.tile_m

    def padded_tail_m(self, m: int) -> int:
        tail = self.tail_m(m)
        return (tail + M_TAIL_ALIGN - 1) // M_TAIL_ALIGN * M_TAIL_ALIGN if tail else 0

    def comm_rounds(self, m: int) -> List[int]:
        """每轮搬的行数: tileCnt 个整块 + 可能一个尾块。长度 = kernel 的 commTurn。"""
        rows = [self.tile_m] * self.tile_cnt(m)
        if self.tail_m(m):
            rows.append(self.tail_m(m))
        return rows or [m]

    def head_rows(self, m: int) -> int:
        """kernel 的 headRows: 本卡数据里被整块覆盖的行。尾行不在 HEAD, 在 TAIL。"""
        return self.tile_cnt(m) * self.tile_m
