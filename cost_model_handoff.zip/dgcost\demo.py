"""可运行的示例场景。

    python3 cost_model/demo.py
"""

from __future__ import annotations

from .estimator import estimate, fit_balance_estimate
from .params import BYTES_PER_MB, Cut, CommCalib, MmCalib, Shape
from .search import sweep
from .slots import (comm_chain_is_critical, min_slot_depth, slot_depth_vs_budget,
                    tiling_slot_num, win_layout)
from .worktime import block_times, comm_time_round

HOST_TILE_M = 512    # all_gather_matmul_v3_tiling.cpp 的 COMM_TILE_M


def _report(tag: str, shape: Shape, comm: CommCalib, mm: MmCalib) -> None:
    m = shape.m_per_rank
    slot = tiling_slot_num(shape, HOST_TILE_M)
    cut = Cut(HOST_TILE_M, slot)
    head, main, tail = block_times(shape, mm, cut)
    tx = comm_time_round(shape, comm, cut.comm_rounds(m)[0])
    est = estimate(shape, comm, mm, cut)

    print("=" * 92)
    print(tag)
    print(f"  m/卡={m} k={shape.k} n={shape.n} P={shape.rank_size}  "
          f"标定 k={comm.slope_us_per_mb} b={comm.round_overhead_us} c={comm.fixed_overhead_us}")
    print(f"\n  单轮工时  τ_x={tx:.2f}  τ_m={main[0] if main else 0.0:.2f}  "
          f"τ_h={head:.2f}  τ_t={tail:.2f}   τ_x/τ_m={tx / main[0] if main else float('nan'):.2f}")
    print(f"  当前切分  tileM={HOST_TILE_M} slotNum={slot} "
          f"({cut.tile_cnt(m)} 个 MAIN 轮 + 尾块 {cut.tail_m(m)} 行)")
    print(f"  预估      {est}")
    print(f"  fit_balance 对照 {fit_balance_estimate(shape, comm, mm, cut):.2f} us")

    print(f"\n  [块长扫描] 前 5 名")
    print(f"{'':6}{'tileM':>6}{'slot':>6}{'轮数':>6}{'预估(us)':>12}{'阻塞(us)':>10}{'瓶颈':>7}{'fit_balance':>13}")
    best = sweep(shape, comm, mm)
    for row in best[:5]:
        print(f"{'':6}{row['tile_m']:>6}{row['slot_num']:>6}{row['rounds']:>6}"
              f"{row['makespan_us']:>12.2f}{row['stall_us']:>10.2f}{row['bound']:>7}"
              f"{row['fit_balance_us']:>13.2f}")
    gain = est.makespan_us - best[0]["makespan_us"]
    print(f"{'':6}最优相对当前 {HOST_TILE_M}: {-gain:+.2f} us ({-gain / est.makespan_us * 100:+.1f}%)")

    print(f"\n  [槽深] S_min 对称={min_slot_depth(shape, comm, mm, cut)} "
          f"慢卡30%={min_slot_depth(shape, comm, mm, cut, 1.3)} / 轮数={est.rounds} / 预算给={slot}"
          f"   {'通信链关键' if comm_chain_is_critical(shape, comm, mm, cut) else 'cube 链关键'}")
    print(f"  [win 预算] 全量足迹 {win_layout(shape, HOST_TILE_M).full_bytes / BYTES_PER_MB:.1f} MB")
    print(f"{'':6}{'预算(MB)':>10}{'slot':>6}{'S_min':>7}{'占用(MB)':>10}{'预估(us)':>12}{'阻塞(us)':>10}")
    for row in slot_depth_vs_budget(shape, comm, mm, HOST_TILE_M):
        mark = "  <- host 写死值" if row["budget_mb"] == 400 else ""
        print(f"{'':6}{row['budget_mb']:>10}{row['slot_num']:>6}{row['s_min']:>7}"
              f"{row['used_bytes'] / BYTES_PER_MB:>10.1f}{row['makespan_us']:>12.2f}"
              f"{row['stall_us']:>10.2f}{mark}")

    print(f"\n  [慢卡] 1 号卡通信慢 30%")
    for sn in sorted({2, slot}):
        if sn > est.rounds:
            continue
        a = estimate(shape, comm, mm, Cut(HOST_TILE_M, sn))
        b = estimate(shape, comm, mm, Cut(HOST_TILE_M, sn), slow_rank_factor=1.3)
        print(f"{'':6}slotNum={sn:<3} 对称 {a.makespan_us:9.2f} | 有慢卡 {b.makespan_us:9.2f} "
              f"| 代价 {b.makespan_us - a.makespan_us:+8.2f} us")

    front = estimate(shape, comm, mm, cut, head_first=True).makespan_us
    back = estimate(shape, comm, mm, cut, head_first=False).makespan_us
    print(f"\n  [本地块位置] FRONT {front:.2f} | BACK {back:.2f} | 前置收益 {back - front:+.2f} us"
          f"   (前置性由不在本仓的 SDK 调度器决定)")
    print()


def main() -> None:
    mm = MmCalib(core_num=32)
    demo_row = dict(slope_us_per_mb=3.2, round_overhead_us=4.45, fixed_overhead_us=1.8)
    aicpu_row = dict(slope_us_per_mb=26.5894, round_overhead_us=33.17, fixed_overhead_us=20.58)

    # 以下 k/b/c 都不是本算子的标定值, 见模块 docstring。只看结构, 不要据此定块长。
    _report("场景 A  计算瓶颈 (k/b/c 取自 README 示例块的演示数)",
            Shape(m_per_rank=4096, k=4096, n=4096, rank_size=8), CommCalib(**demo_row), mm)
    _report("场景 B  通算接近配平 (k/b/c 借 AICPU 4P 实测行)",
            Shape(m_per_rank=4096, k=4096, n=6144, rank_size=4), CommCalib(**aicpu_row), mm)
    _report("场景 C  通信瓶颈 (同上借位行, n 小)",
            Shape(m_per_rank=4096, k=4096, n=1024, rank_size=4), CommCalib(**aicpu_row), mm)
    _report("场景 D  UT 形状 m2061 带尾块 (同上借位行)",
            Shape(m_per_rank=2061, k=4096, n=2560, rank_size=4), CommCalib(**aicpu_row), mm)
    _report("场景 E  win 预算受限 m8192 P16 (同上借位行)",
            Shape(m_per_rank=8192, k=4096, n=1024, rank_size=16), CommCalib(**aicpu_row), mm)


if __name__ == "__main__":
    _demo()
