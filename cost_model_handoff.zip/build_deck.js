const pptxgen = require('pptxgenjs');
const fs = require('fs');

const ROOT = 'C:/Users/caiji/Desktop/cost_model';
const ARCH = ROOT + '/architecture_final.png';
const CURVES = ROOT + '/measurement_agmm_2p/curves/';

function pngSize(p) {
  const b = fs.readFileSync(p);
  return { w: b.readUInt32BE(16), h: b.readUInt32BE(20) };
}

const FONT = 'Microsoft YaHei';
const NAVY = '1F2A44';
const BLUE = '0072B2';
const TEXT = '3D4756';
const MUTED = '5F6B7A';
const CARD = 'F4F6F9';

const pres = new pptxgen();
pres.layout = 'LAYOUT_WIDE';
pres.title = 'AllGatherMatmul 融合算子耗时预测：方法与实验';

function text(slide, str, o) {
  slide.addText(str, Object.assign({ margin: 0, isTextBox: true, fontFace: FONT, color: TEXT }, o));
}
function card(slide, x, y, w, h) {
  slide.addShape(pres.shapes.RECTANGLE, { x, y, w, h, fill: { color: CARD }, line: { color: CARD, width: 0 } });
}
function badge(slide, x, y, n) {
  slide.addShape(pres.shapes.OVAL, { x, y, w: 0.3, h: 0.3, fill: { color: BLUE }, line: { color: BLUE, width: 0 } });
  text(slide, String(n), { x, y, w: 0.3, h: 0.3, align: 'center', valign: 'middle', fontSize: 11, bold: true, color: 'FFFFFF' });
}
function curveImg(slide, file, x, y, w) {
  const s = pngSize(CURVES + file);
  const h = w * s.h / s.w;
  slide.addImage({ path: CURVES + file, x, y, w, h });
  return h;
}

// ---------- Slide 1: method and architecture ----------
const s1 = pres.addSlide();
s1.background = { color: 'FFFFFF' };
text(s1, '依赖图 + 递推式，少量实测参数即可预测融合算子耗时', {
  x: 0.45, y: 0.3, w: 12.4, h: 0.6, fontSize: 24, bold: true, color: NAVY,
});
text(s1, 'AllGatherMatmul · 方法与架构', {
  x: 0.45, y: 0.95, w: 12.4, h: 0.35, fontSize: 14, color: MUTED,
});
const archSz = pngSize(ARCH);
const archH = 5.45;
s1.addImage({ path: ARCH, x: 0.45, y: 1.5, w: archH * archSz.w / archSz.h, h: archH });

card(s1, 9.45, 1.5, 3.45, 3.6);
text(s1, '方法', { x: 9.65, y: 1.66, w: 3.1, h: 0.32, fontSize: 15, bold: true, color: NAVY });
const steps = [
  ['画依赖图', '通信与计算的先后、等待关系'],
  ['递推求耗时', '最长路即耗时，结构与平台无关'],
  ['修正并标定', '三项修正，约 10 个参数实测标定'],
];
steps.forEach((s, i) => {
  const y = 2.2 + i * 0.98;
  badge(s1, 9.65, y + 0.03, i + 1);
  text(s1, [
    { text: s[0], options: { bold: true, color: NAVY, breakLine: true } },
    { text: s[1], options: { color: TEXT } },
  ], { x: 10.1, y, w: 2.65, h: 0.8, fontSize: 12, valign: 'top' });
});

card(s1, 9.45, 5.35, 3.45, 1.55);
text(s1, '输入 → 输出', { x: 9.65, y: 5.5, w: 3.1, h: 0.32, fontSize: 15, bold: true, color: NAVY });
text(s1, [
  { text: '输入  ', options: { bold: true, color: NAVY } },
  { text: '形状 m、n、k、P，切分 tileM', options: { color: TEXT, breakLine: true } },
  { text: '输出  ', options: { bold: true, color: NAVY } },
  { text: '耗时 T 及各部分分解', options: { color: TEXT } },
], { x: 9.65, y: 5.9, w: 3.1, h: 0.85, fontSize: 12, valign: 'top' });

text(s1, '已标定平台：Ascend 910_93（2 卡，bf16，K=4096）；结构与平台无关，换平台只需重标定。', {
  x: 0.45, y: 7.12, w: 12.4, h: 0.26, fontSize: 10, color: MUTED,
});

s1.addNotes(
  '讲法：先看右侧方法三步，再沿左侧架构图从左到右读。\n' +
  '1. 输入是形状参数与切分粒度 tileM，不需要 kernel 源码。\n' +
  '2. 结构层：Disjunctive Graph 中，合取弧表示依赖，析取弧表示缓冲槽互斥（M[r-S] 到 X[r]）。递推式给出结构估时 T_struct，只依赖结构，与平台无关。\n' +
  '3. 修正层：参数由实测数据标定。经验修正三项为 serial、floor、Σg，均为图外的经验补偿；系数由实测拟合，物理含义仅作定性解释，serial 的具体机制待验证。\n' +
  '4. 现有公式把通信和计算当作两条标量链，看不见缓冲槽造成的相互等待，也解释不了切分粒度的影响。\n' +
  '注意：示意图为简化版，省略了放行延迟项（release 与阻塞汇合）；完整递推见文字说明。'
);

// ---------- Slide 2: sweep experiments on the four scan shapes ----------
const s2 = pres.addSlide();
s2.background = { color: 'FFFFFF' };
text(s2, '切分粒度扫描：4 组形状上，模型跟随实测趋势，34 点中 33 点在 ±10% 内', {
  x: 0.45, y: 0.3, w: 12.4, h: 0.6, fontSize: 22, bold: true, color: NAVY,
});
text(s2, '实线为实测（两遍中位数），虚线为模型预测（dgcost）；横轴为每块行数 tileM，图题为每卡 m 行 × n 列', {
  x: 0.45, y: 0.95, w: 12.4, h: 0.35, fontSize: 13, color: MUTED,
});
const colX = [0.45, 4.7];
const rowY = [1.5, 4.37];
const cw2 = 4.1;
const scan = ['tilem_curve_4096x1024.png', 'tilem_curve_4096x6144.png', 'tilem_curve_8192x1024.png', 'tilem_curve_2048x1024.png'];
scan.forEach((f, i) => curveImg(s2, f, colX[i % 2], rowY[Math.floor(i / 2)], cw2));

const stats = [
  ['33 / 34', '切分扫描点误差在 ±10% 以内（本页 4 组形状）'],
  ['131 / 142', '拟合集实测点误差在 ±10% 以内'],
  ['86 / 86', '留出验证点误差在 ±10% 以内'],
  ['32 / 32', 'K=2048、8192 扩展验证点误差在 ±10% 以内'],
];
stats.forEach((s, i) => {
  const y = 1.5 + i * 1.35;
  card(s2, 9.05, y, 3.85, 1.2);
  text(s2, s[0], { x: 9.27, y: y + 0.12, w: 3.5, h: 0.5, fontSize: 26, bold: true, color: BLUE });
  text(s2, s[1], { x: 9.27, y: y + 0.66, w: 3.5, h: 0.46, fontSize: 11, color: TEXT, valign: 'top' });
});

text(s2, '实测：2×Ascend 910_93，bf16，K=4096。模型：dgcost（A2_HCCL_910_93 标定）。K≠4096、卡数≠2、其它数据类型未验证。', {
  x: 0.45, y: 7.12, w: 12.4, h: 0.26, fontSize: 10, color: MUTED,
});

s2.addNotes(
  '讲法：左上 4096×1024 是通信瓶颈形状，切分越细（R 越大）耗时越高，模型的曲线形状与实测一致。右下 4096×6144 是计算瓶颈形状，耗时基本不随切分变化，模型同样平坦（tileM≥256 时相差约 2% 以内）。\n' +
  '这 4 组形状是切分扫描的全部数据（34 点）。数字来源：dgcost/A2_910_93_CALIBRATION.md。\n' +
  '边界：只在 2 卡、bf16、K=4096 及 K=2048/8192（逐 K 参数）下验证；其它卡数与数据类型未经实测。'
);

// ---------- Slide 3: six further shapes, with honest deviations ----------
const s3 = pres.addSlide();
s3.background = { color: 'FFFFFF' };
text(s3, '更多形状：整体趋势一致，切分极细或极粗时偏差较大', {
  x: 0.45, y: 0.3, w: 12.4, h: 0.6, fontSize: 24, bold: true, color: NAVY,
});
text(s3, '以下 6 组形状未参与切分扫描，用于检验模型的外推能力；偏差写在图下方', {
  x: 0.45, y: 0.95, w: 12.4, h: 0.35, fontSize: 13, color: MUTED,
});
const cw3 = 4.0;
const cx3 = [0.45, 4.65, 8.85];
const ry3 = [1.45, 4.2];
const more = [
  'tilem_curve_5120x1024.png', 'tilem_curve_7168x1024.png', 'tilem_curve_6144x1024.png',
  'tilem_curve_12288x1024.png', 'tilem_curve_1024x3200.png', 'tilem_curve_2048x3200.png',
];
more.forEach((f, i) => curveImg(s3, f, cx3[i % 3], ry3[Math.floor(i / 3)], cw3));

text(s3, '偏差说明：12288×1024 整体偏低约 10%；1024×3200、2048×3200 在 tileM=64 处偏低约 13%；6144×1024 在 tileM=6144 处偏高约 6%。', {
  x: 0.45, y: 6.88, w: 12.4, h: 0.24, fontSize: 11, color: TEXT, valign: 'top',
});
text(s3, '实测：2×Ascend 910_93，bf16，K=4096。模型：dgcost（A2_HCCL_910_93 标定）。以上形状的完整误差见 measurement_agmm_2p/curves/README.md。', {
  x: 0.45, y: 7.12, w: 12.4, h: 0.26, fontSize: 10, color: MUTED,
});

s3.addNotes(
  '讲法：这 6 组不在切分扫描内，用来看模型在没参与标定的形状上表现如何。5120×1024、7168×1024 与实测趋势吻合较好。\n' +
  '偏差要如实说：12288×1024 在中等切分（tileM 约 1280–3072）整体偏低约 10%；1024×3200、2048×3200 在 tileM=64 偏低约 13%；6144×1024 在 tileM=6144 偏高约 6%。\n' +
  '这些偏差说明：极端切分（R 很大或 R=1 附近）和大 n 的形状仍需更多标定数据。'
);

pres.writeFile({ fileName: ROOT + '/method_summary.pptx' }).then(f => console.log('written', f));
