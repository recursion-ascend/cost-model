"""从仓内 C++ 实测拟合表构造标定。每个常数标注出处, 便于核对与更新。

能标定的只有通信曲线和平台算力/频率。下面三项任何表都给不出, 默认留 0:

  τ_b          每轮跨卡 barrier —— 被通信拟合的截距吸收, 无法分离
  release      AIC Release 到 AIV 可见 —— 同上, 且只经阻塞弧进模型
  截距的归属   拟合在"未切分的整次传输"上做, 分不出"每轮"还是"一次性"

最后一项是唯一影响结论的: 见 round_overhead_is_per_round 开关。
"""

from __future__ import annotations

from dataclasses import dataclass

from .params import CommCalib

BYTES_PER_MB = 1024.0 * 1024.0


@dataclass(frozen=True)
class HcclFit:
    """C++ HCCLFittingParameters 的前 8 个字段, 字段序同 formulaic_tiling_datatype.h:127。

    CommTime(x) 的分段 (hccl_performance.cpp:165):
        x > size_b2 : g*x + off
        x > size_b1 : a*x^2 + b*x + c
        否则        : small_const        <- C++ 复用了 timeToSizeBoundary1 这个字段
    结果再 /= comm_time_factor。
    """
    size_b1: float
    size_b2: float
    g: float
    off: float
    a: float
    b: float
    c: float
    small_const: float
    note: str = ""

    def time_us(self, x_mb: float, comm_time_factor: float = 1.0) -> float:
        if x_mb > self.size_b2:
            r = self.g * x_mb + self.off
        elif x_mb > self.size_b1:
            r = self.a * x_mb * x_mb + self.b * x_mb + self.c
        else:
            r = self.small_const
        return r / comm_time_factor

    @property
    def is_pure_linear(self) -> bool:
        """b1 = b2 = 0 时三段退化为一条直线, 才能无损折成 CommCalib。"""
        return self.size_b1 == 0.0 and self.size_b2 == 0.0


# ---------------------------------------------------------------------------
# 通信: hccl_performance_arch35.cpp:18  ARCH35_FITTING_PARAMETER_MAP
#   键 = <系列码>_<KernelType>_<TopoType>_<rankDim>, 系列码 4 = DAV_3510 = A5 950
#   KernelType: 0 ALL_REDUCE, 1 ALL_GATHER, 3 ALL_TO_ALL, 4 RS_VIA_A2A, 5 AR_TWO_SHOT
#   TopoType:   0 STANDARD_CARD(标卡4P), 1 EIGHT_P
# ---------------------------------------------------------------------------
A5_ALLGATHER_4P = HcclFit(0, 0, 5.841842, 8.590666, 0, 0, 0, 0, "4_1_0_4 A5 allGather 标卡4P")
A5_RS_A2A_4P    = HcclFit(0, 0, 5.8087, 5.6810, 0, 0, 0, 0, "4_4_0_4 A5 reduceScatter 标卡4P")
A5_ALLTOALL_4P  = HcclFit(0, 0, 5.8416, 5.8148, 0, 0, 0, 0, "4_3_0_4 A5 alltoall 标卡4P")
A5_RS_A2A_8P    = HcclFit(0, 0, 2.642023, 7.700559, 0, 0, 0, 0, "4_4_1_8 A5 RS POD8P")
A5_ALLTOALL_8P  = HcclFit(0, 0, 2.5386, 7.6265, 0, 0, 0, 0, "4_3_1_8 A5 alltoall POD8P")

# ---------------------------------------------------------------------------
# 通信: hccl_performance.cpp:28  FITTING_PARAMETER_MAP, 键 = <系列码>_<HCCLType>
#   系列码 0 = SOC910_B (A2), 2 = SOC910_93 (A3), 4 = DAV_3510 (A5)
#   HCCLType: 0 FULL_MESH, 1 DOUBLE_RING
# ---------------------------------------------------------------------------
A2_FULLMESH = HcclFit(64.0 / 1024, 8, 13.58491263, 61.508333,
                      -0.9698202, 27.0622573, 14.769, 18, "0_0 A2 910B fullmesh (DEFAULT)")
A3_DOUBLERING = HcclFit(2.0, 2.0, 11.38154641, 248.151561,
                        0.0, 0.0, 250.0, 250.0, "2_1 A3 910_93 doublering")
A5_FULLMESH_GENERIC = HcclFit(0.032, 1.371, 2.59568, 5.8887,
                              0, 2.86702, 5.608, 5.6997, "4_0 A5 fullmesh (泛用默认)")


def full_mesh_comm_time_factor(rank_dim: int, comm_grow_ratio: float = 1.0) -> float:
    """hccl_performance.cpp:56 SetFullMeshCommTimeFactor。

    commTimeFactor_ = FULL_MESH_TIME_FACTOR(2.0), 再 /= (FITTING_RANK(8) / rankDim)。
    A2/A3 的算子侧还会恒 /= commGrowRatio(1.15), 见 all_gather_formulaic_tiling_a2a3.cpp。
    CommTime 最后做 result /= commTimeFactor_, 所以 factor 越小耗时越大。
    """
    factor = 2.0 / (8.0 / rank_dim)
    return factor / comm_grow_ratio if comm_grow_ratio > 0 else factor


def comm_calib_from_fit(fit: HcclFit, look_up_tile_num: int,
                        comm_time_factor: float = 1.0,
                        round_overhead_is_per_round: bool = True) -> CommCalib:
    """把拟合行折成本模型的 CommCalib (自变量 = 每卡每轮字节)。

    C++ 的自变量是 mSize * commMatrixLen * lookUpTileNum_ * realDtypeSize / MB,
    本模型是 rows * (k * a_bits/8) / MB —— k 与 dtype 两边一致, 由 Shape 提供,
    所以这里只需补上 look_up_tile_num 这个倍数差。

    round_overhead_is_per_round 是**本模型最吃重的未定参数**:
      True  —— 截距当成每轮固定开销, 进 round_overhead_us, 通信链里乘轮数 R
      False —— 截距当成算子级一次性, 进 fixed_overhead_us, 只付一次
    两者在 tileM=512/m=4096 上让 makespan 差 15%, 且给出相反的最优块长。
    kernel 确实发 R 次 Commit/Drain/barrier, 所以 True 方向正确; 但拟合是在
    未切分的整次传输上做的, 这个截距是否等于每轮开销没有被验证过。
    只能靠实测定: 固定 m 扫 tileM, 对轮数 R 回归, 斜率即每轮开销。
    """
    if not fit.is_pure_linear:
        raise ValueError(f"{fit.note}: 分段非线性, 无法无损折成线性 CommCalib; "
                         f"请直接用 HcclFit.time_us 或只在 x>size_b2 的线性段使用")
    slope = fit.g * look_up_tile_num / comm_time_factor
    intercept = fit.off / comm_time_factor
    if round_overhead_is_per_round:
        return CommCalib(slope, intercept, 0.0)
    return CommCalib(slope, 0.0, intercept)


def a5_allgather_4p(round_overhead_is_per_round: bool = True) -> CommCalib:
    """v3 常用场景: A5 950, AllGather, 标卡 4P。

    InitArch35Parameters (hccl_performance_arch35.cpp:58): ALL_GATHER 时
    lookUpTileNum_ = rankDim, commTimeFactor_ = 1; 键精确命中故不再额外折算。
    !! 这行标的是 HCCL fullmesh, 而 v3 走 AIV_URMA WriteNbi/Drain, 不是同一条链路。
    """
    return comm_calib_from_fit(A5_ALLGATHER_4P, look_up_tile_num=4, comm_time_factor=1.0,
                               round_overhead_is_per_round=round_overhead_is_per_round)
