"""切分搜索: 按预估耗时给 (tileM, slotNum) 排序。"""

from __future__ import annotations

from typing import List, Optional, Tuple

from .estimator import estimate, fit_balance_estimate
from .params import MAX_COMM_ROUNDS, M_TAIL_ALIGN, Cut, CommCalib, MmCalib, Shape
from .slots import WinBudget, tiling_slot_num


TILE_CANDIDATES = (128, 192, 256, 320, 384, 512, 640, 768, 1024, 1536, 2048)


def sweep(shape: Shape, comm: CommCalib, mm: MmCalib,
          tile_candidates: Optional[Tuple[int, ...]] = None,
          budget: Optional[WinBudget] = None) -> List[dict]:
    """按预估耗时给 (tileM, slotNum) 排序。槽深取预算允许的范围内若干档。"""
    candidates = tile_candidates or TILE_CANDIDATES
    out = []
    for tile_m in candidates:
        if tile_m > shape.m_per_rank or tile_m % M_TAIL_ALIGN:
            continue
        rounds = len(Cut(tile_m, 1).comm_rounds(shape.m_per_rank))
        if rounds > MAX_COMM_ROUNDS:
            continue
        allowed = tiling_slot_num(shape, tile_m, budget)
        for slot in sorted({2, 3, 4, 6, 8, allowed}):
            if slot > allowed or slot > rounds:
                continue
            est = estimate(shape, comm, mm, Cut(tile_m, slot))
            out.append({"tile_m": tile_m, "slot_num": slot, "rounds": rounds,
                        "makespan_us": est.makespan_us, "stall_us": est.stall_us,
                        "bound": est.bound,
                        "fit_balance_us": fit_balance_estimate(shape, comm, mm, Cut(tile_m, slot))})
    # 同分时偏好轮数更少、块更大: 每轮同步次数更低, 实现风险也更小
    return sorted(out, key=lambda d: (round(d["makespan_us"], 3), d["rounds"], -d["tile_m"]))
