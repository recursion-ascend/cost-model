# -*- coding: utf-8 -*-
"""A2 / Ascend 910_93 上的 AllGatherMatmul(arch22, V1) 本机标定 (2026-10-19)。

在 dgcost 析取图递推

    e2e = estimate(shape, A2_910_93_COMM, CutActual(rounds, tail),
                   profile=A2_HCCL_910_93).makespan_us
        + serial + floor + Σg

    serial = c0*D + c1*(m/1024)*(k/4096) + c2*(m/1024)*(D/50)  D = K*n*2B/MB (串行段;
                                                         c1 项按行字节数 K*2B 归一, 2026-10-20 K 扩展修订)
    floor  = max(0, q0 - q1*T_mm)                        (T_mm: 矩阵乘累计工时; 小形状固定开销)
    Σg     = Σ_轮 g0*max(0, t0 - 每轮数据量MB)            (小块每轮成本)

"""

from __future__ import annotations

from typing import List, Tuple

from .estimator import estimate
from .params import BYTES_PER_MB, CommCalib, Cut, Shape
from .profiles import A2_HCCL_910_93

K_DEFAULT = 4096          
RANK_SIZE = 2             

#: 通信标定
A2_910_93_COMM = CommCalib(slope_us_per_mb=4.4023, round_overhead_us=12.9265,
                           fixed_overhead_us=54.9089)

#: 拟合系数
A2_910_93_CORR = dict(q0=46.5509, q1=1.2034, g0=3.0457, t0=1.7053,
                      c0=2.9808, c1=45.7643, c2=35.0970)

#: 逐 K 参数表（2026-10-20）: 对 K=2048/8192 单独标定 b、c、t0、c1 四个参数, 其余沿用基线。
#: 标定数据: 每 K 16 点（10 标定 + 6 留出全过）; 全 16 点 LOO 交叉验证全过（最大 9.7%）。
#: 未列入的 K 走全局降级式（c1 项按行字节数归一, 精度未验证）。
A2_910_93_PER_K = {
    2048: dict(b=2.4557, c=77.7939, t0=5.1872, c1=48.3868),
    8192: dict(b=18.5198, c=48.5762, t0=1.7053, c1=47.5857),
}


class CutActual(Cut):
    """按实测切分驱动递推, 而非均匀 tile_m 假设。
    """

    def __init__(self, rounds: List[int], tail: int = 0):
        super().__init__(max(rounds) if rounds else 1, len(rounds) + (1 if tail else 0))
        self._rounds = list(rounds)
        self._tail = int(tail)

    def comm_rounds(self, m: int) -> List[int]:
        return list(self._rounds) + ([self._tail] if self._tail else [])

    def tile_cnt(self, m: int) -> int:
        return len(self._rounds)

    def tail_m(self, m: int) -> int:
        return self._tail

    def padded_tail_m(self, m: int) -> int:
        return ((self._tail + 15) // 16 * 16) if self._tail else 0


def cut_from_comm_turn(m: int, comm_turn: int) -> Tuple[List[int], int]:
    tile_len = 1
    if m > comm_turn:
        tile_len = m // comm_turn
    tile_len = (tile_len + 63) // 64 * 64
    tile_m = tile_len if m > tile_len else m
    tc = m // tile_m
    return [tile_m] * tc, m - tc * tile_m


def predict(m: int, n: int, rounds: List[int], tail: int = 0,
            k: int = K_DEFAULT, rank_size: int = RANK_SIZE) -> float:
    """预测一次 AllGatherMatmul 的端到端耗时。K 在逐 K 参数表中时用该 K 的参数。"""
    shape = Shape(m_per_rank=m, k=k, n=n, rank_size=rank_size, a_bits=16)
    ov = A2_910_93_PER_K.get(k)
    comm = A2_910_93_COMM
    if ov:
        comm = CommCalib(slope_us_per_mb=comm.slope_us_per_mb,
                         round_overhead_us=ov.get('b', comm.round_overhead_us),
                         fixed_overhead_us=ov.get('c', comm.fixed_overhead_us))
    est = estimate(shape, comm, A2_HCCL_910_93.mm,
                   CutActual(rounds, tail), profile=A2_HCCL_910_93)

    def mm_us(rows: int, shares: int) -> float:
        return rows * shares * n * k / (4096.0 * 20 * 1.65e9) * 1e6

    corr = A2_910_93_CORR if not ov else {
        **A2_910_93_CORR,
        't0': ov.get('t0', A2_910_93_CORR['t0']),
        'c1': ov.get('c1', A2_910_93_CORR['c1']),
    }
    d_mb = k * n * 2 / BYTES_PER_MB
    mv = m / 1024.0
    mac_chain = (mm_us(m, 1) + sum(mm_us(r, 1) for r in rounds)
                 + (mm_us(tail, 1) if tail else 0.0))
    floor = max(0.0, corr['q0'] - corr['q1'] * mac_chain)
    extra = sum(corr['g0'] * max(0.0, corr['t0'] - r * k * 2 / BYTES_PER_MB)
                for r in list(rounds) + ([tail] if tail else []))
    serial = (corr['c0'] * d_mb + corr['c1'] * mv * (k / float(K_DEFAULT))
              + corr['c2'] * mv * d_mb / 50.0)
    return est.makespan_us + serial + floor + extra


if __name__ == '__main__':
    for m, n, ct in [(4096, 1024, 4), (8192, 1024, 8), (2048, 1024, 0), (6144, 1024, 0)]:
        rounds, tail = ([1280] * 4, 1024) if (m, n, ct) == (6144, 1024, 0) \
            else (([m], 0) if ct == 0 else cut_from_comm_turn(m, ct))
        print(f"m={m} n={n} commTurn={ct}: 预测 {predict(m, n, rounds, tail):.1f} 微秒")
