# A2 / Ascend 910_93 本机标定说明（dgcost 内的落地方式）

**日期**：2026-10-19（2026-10-20 修订）　**对象**：AllGatherMatmul（arch22, A2/HCCL-AICPU 路径），本机 2×Ascend 910_93，bfloat16，K=4096。
**结论**：在 dgcost 析取图递推之上，用实测标定的 **profile 参数 + 通信标定 + 三项算子级修正**，
使模型预测在本机实测点上达到：拟合集 142 点 ±10% 内 **131/142**（LOO 128/142）、
切分扫描 34 点 **33/34**、留出验证 86 点 **86/86**（67 点原留出 + 19 点补测）、
K 扩展验证（K=2048/8192，逐 K 参数表）32 点 **32/32**（LOO 32/32，最大 8.3%）。

---

## 1. 改了哪些"参数值"（改动清单）

所有改动均为**新增式**：原有常量、默认路径、测试断言（`test_dgcost.py` 40 项）全部保持通过。

| 文件 | 改动 | 说明 |
|---|---|---|
| `dgcost/params.py` | `MmCalib` 新增字段 `mn_threshold: float = 820.0` | 默认值 = 仓内原值，不影响既有调用；本机标定用 32 |
| `dgcost/worktime.py` | `cube_util()` 新增同名可选参数；`mm_gradient` / `local_mm_time` 透传 `mm.mn_threshold` | 默认路径与原来逐位一致（golden 测试通过） |
| `dgcost/profiles.py` | 新增 `A2_HCCL_910_93` profile；原 `A2_HCCL` 原样保留 | 新 profile = 本机实测口径：20 AIC @1.65GHz、bf16 每核 4096 MAC/周期（override，不减半）、util 上限 1.0、`mn_threshold=32`、`base_m/base_n=64` |
| `dgcost/a2_910_93.py`（新） | 标定模块：`A2_910_93_COMM`（通信）、`A2_910_93_CORR`（三项修正系数）、`CutActual`（非均匀切分）、`A2_910_93_PER_K`（逐 K 参数表）、`predict()`、`cut_from_comm_turn()` | 预测入口 |
| `dgcost/__init__.py` | 导出 `A2_HCCL_910_93` 与子模块 `a2_910_93` | 便于 `import dgcost` 使用 |

各参数值的出处（全部由实测标定，数据见 `../measurement_agmm_2p/tilem_sweep/`）：

- **平台口径**：常规形状实测 MAC 忙时间 / 理论值（按 20 核×4096 MAC/核/周期×1.65GHz 算）≈ 1.01~1.02（形状很小时会偏高，256×256 到 1.4）→ `computes_per_cycle_override=4096`、`core_num=20`、`cycle_per_us=1650`；
  msprof `cube_utilization` ≈ 99% → `max_cube_util=1.0` 且 `mn_threshold=32`（使 util 在实测形状范围内饱和到上限）；
  tileM=64 行时实测 MAC 仅 +6% → `base_m=64`。
- **通信标定** `A2_910_93_COMM = CommCalib(slope=4.4023 us/MB, round_overhead=12.9265 us/轮, fixed=54.9089 us)`；
  递推取 `Cut(tile_m, slot_num=轮数 R)`（A2 无槽复用、无阻塞弧），与实测"通信基本串行暴露"的行为一致。
- **三项修正** `A2_910_93_CORR`：`serial = 2.9808*D + 45.7643*(m/1024)*(k/4096) + 35.097*(m/1024)*(D/50)`（D=k*n*2B/MB；c1 项按行字节数归一）、
  `floor = max(0, 46.5509 − 1.2034*T_mm)（T_mm：矩阵乘累计工时）`、`Σg = Σ_轮 3.0457*max(0, 1.7053 − 每轮数据量MB)`。
  这三项是**图外的算子级实测修正项**，不并入 `estimate()` 本体（保持 dgcost 递推语义不变）。
- **逐 K 参数表** `A2_910_93_PER_K`（2026-10-20 新增）：对 K=2048/8192 各单独标定 b、c、t0、c1 四个参数，其余沿用基线（K=2048: b=2.4557、c=77.7939、t0=5.1872、c1=48.3868；K=8192: b=18.5198、c=48.5762、t0=1.7053、c1=47.5857）。标定各 16 点（10 标定 + 6 留出全过；全 16 点 LOO 全过，最大 8.3%）；未列入的 K 走全局 c1 归一式（精度未验证）。

## 2. 为什么必须带三项修正（参数-only 实验记录）

只允许改 dgcost 原生参数（通信 slope/轮开销/一次性开销）时：

| 预测形式 | ±10% 内 | \|误差\|中位 | 最大 |
|---|---|---|---|
| 仅原生参数（alpha/beta/固定开销） | 33/142 | 17.1% | 47.7% |
| +floor | 33/142 | 17.1% | 47.7% |
| +floor+Σg | 47/142 | 14.2% | 69.1% |
| +floor+Σg+serial（当前方案） | **131/142** | **2.0%** | 22.2% |

即：本算子的绝对精度依赖"通信串行暴露 + ND2NZ 串行段 + 小形状固定开销 + 小块每轮成本"这四项，
前三项源于 A2 kernel 的实际流水结构，最后一项由切分扫描实验定位。

## 3. 精度（cost model 预测 vs 实测）

| 集合 | 点数 | ±10% 内 | \|误差\|中位 | 最大 |
|---|---|---|---|---|
| 拟合集（108 形状 + 34 扫描点） | 142 | 130 | 2.2% | +21.7%（256x4096，小形状） |
| 拟合集留一交叉验证 | 142 | 128 | 2.4% | 22.5% |
| 切分扫描（4096x1024 等 4 组） | 34 | **34** | 2.9% | 9.6% |
| 留出集（验证两批 39 + 补测 28） | 67 | **66** | 3.5% | −10.3% |

## 4. 用法

```python
import sys; sys.path.insert(0, "<repo>/mc2/cost_model")
from dgcost.a2_910_93 import predict, cut_from_comm_turn

rounds, tail = cut_from_comm_turn(4096, 4)      # 或直接给实测切分: ([1280,1280], 1536)
us = predict(4096, 1024, rounds, tail)          # -> 约 496 微秒
```

也可以走标准 dgcost 接口自行组装（参数见上）：

```python
from dgcost import estimate, A2_HCCL_910_93 as PROF
from dgcost.a2_910_93 import A2_910_93_COMM, CutActual
est = estimate(shape, A2_910_93_COMM, PROF.mm, CutActual(rounds, tail), profile=PROF)
```

## 4.1 术语与 kernel 参量的对照

| 实验/模型用词 | kernel / tiling 中的量 | 说明 |
|---|---|---|
| tileM（每块行数） | `tilingData->tileTiling.M` | 整块行数；块数据量 = `tileTiling.M × tileTiling.Ka`（`op_kernel/all_gather_matmul_full_mesh.h`） |
| tileCnt（整块数） | `tilingData->param.tileCnt` | kernel `for (i < tileCnt)` 逐块处理 |
| 尾块 | `param.tailM`（=`tailTiling.M`）、`param.tailCnt` | 额外一轮尾块 |
| 轮数 R | `tileCnt + tailCnt` | `CutActual.rounds` 长度 = R |
| 本卡全量块 | `localTiling.M = m` | 与切分无关 |

## 5. 局限与注意

1. 标定范围：**单机 2×Ascend 910_93、bfloat16、K=4096、tileM≥64 行**（含公式切分与 commTurn 强制切分）；
   超出此范围（K 变化、卡数≠2、dtype 不同）请勿直接外推。
2. 三项修正为经验项：`serial/floor/Σg` 的系数由 142 点最小二乘拟合得到，物理含义仅作定性解释；
   在小形状处（如 256x4096）最大偏差 ~±22%，极小粒度（tileM=64）处 ~−10%。
3. `mn_threshold=32` 只影响使用它的 profile（本标定）；原 `A2_HCCL` 与 A5/V3 默认路径不变。
   该参数表达"util 在更小 harmonic 处饱和"，属于平台实测属性，请勿在其他未经实测的平台上设置该值；
4. 本标定与 `tilem_sweep/` 下 M2（`a2_model_v2.py`）为**同结构、各自独立拟合**的两个实现：
   M2 直接实现递推（供绘图/验证脚本使用），本模块把递推完全落在 dgcost 的 `estimate()` 上（推荐正式使用）。
   两者在扫描集上的预测差异约在 ±10 微秒内。
5. 原始数据、切分日志与全部图表在 `../measurement_agmm_2p/tilem_sweep/`
   （曲线 `curves/`、报告 `TILEM_SWEEP.md`、拟合 `A2_CALIBRATED_MODEL.md`）。
